import sys
import os
sys.path.append(os.path.abspath('../rcj_soccer_player_b1'))
import helveticrobot

my_robot = helveticrobot.Helveticrobot()
my_robot.run()
