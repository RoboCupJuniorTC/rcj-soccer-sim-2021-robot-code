# rcj_soccer_player controller - ROBOT B1

# Feel free to import built-in libraries
import math

# You can also import scripts that you put into the folder with controller
from rcj_soccer_robot import RCJSoccerRobot, TIME_STEP
import helveticrobot
import utils

my_robot = helveticrobot.Helveticrobot()
my_robot.run()
